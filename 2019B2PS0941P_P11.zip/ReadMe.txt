#############################################################
ReadMe for assignment submitted by 2019B2PS0941P
Practical section number: P11
Asignment question attempted: 1
#############################################################
Team:
1. 2019B2PS0941P   Yuvraj Singh Lathar
2. 2019ABPS0953P   Kovidh Mehta
3. 2019A5PS1084P   Rimen Kaur
#############################################################
Description of how to run the code and observe the output: 
1. The .c file is called 2019B2PS0941_P11.c It is a user driven programme. Standard execution by typing gcc.2019B2PS0941_P11.C and thereafter ./a.out
2. Code is a game of Kaun Banega Crorepati 
3. When you compile the code, it will prompt you to press th enter key. Any other Inuput and code runs from beggining at this stage.
4. The game would start by displaying one question at a time along with its four options on the screen, prompting the user to select the correct option, user can select 1,2,3,4,5(50-50 Lifeline),6(flip the question Lifeline) depending on what he feels is the right option.
5. If the selected option is correct, the corresponding prize money should be displayed.
6. Otherwise, the prize money should be reduced to zero or to the intermediate level.
7. The user can opt for two life lines, such as “50-50”, upon selection of which, two wrong options should be removed from the screen, or “flip the question” that should replace the entire question with a new one on the screen.
8.These life lines can be availed by the user only once (even at the same time as well).
9.Game can either end by user loosing and earning a prizemoney coressponding to the intermediate level or by user winning or earning a prozemoney of Rupees 10 Crore.
10. The use of concepts have been used:
    (i)Global Variable concept
    (ii)Conditional statements( if and else)
    (iii)Fucntions
    (iv)Use of predefined fuction such as Goto(helps to go to a certain point in code when prompted by the user.)
11.The size chart is also given in the starting with all the rules of the game. 
############################################################
Known limitations of the code (if you have not been able to completely/fully implement certain features that were asked):
Code is prepared keeping in mind the quidelines given.NO limitations on what was least asked from us.
On entering any other characters except for number in option code ends abruptly,that is because scanf fails to convert the input as an integer when character/string is passed ,it shows undefined behavior.
(if int is mentioned , the input only should be a number.)
#############################################################
Contributions of the team members:
Yuvraj Singh Lathar - Researched general knowledge questions 
		      Completed first 5 questions of the game 
		      Made Functions Success,Failure_1,Nextques
                      Wrote the rules of the game and decided prize scheme and made prize chart(with array money_won[])
		      Commented the code
Kovidh Mehta       -  Completed next 5 questions
		      Made functions Failure_2,Failure_3,Failure_4
		      Commented the code
		      Made the read me file
		      Wrote the introduction
Rimen Kaur         -  Completed last 5 questions
		      Made Fuctions Invalid,Success_1,Success_2
		     		      
#############################################################